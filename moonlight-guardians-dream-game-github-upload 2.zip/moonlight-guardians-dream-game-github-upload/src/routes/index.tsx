import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import * as THREE from "three";

export const Route = createFileRoute("/")({
  component: DreamersGame,
});

type Phase = "title" | "intro" | "role" | "play" | "win" | "lose";
type RoleKey = "leader" | "attacker" | "defender" | "healer";

const ROLES: Record<RoleKey, {
  name: string;
  tagline: string;
  description: string;
  stats: { dmg: number; range: number; hp: number; speed: number; cooldown: number };
}> = {
  leader:   { name: "The Leader",   tagline: "Moonlit staff wielder",    description: "A guiding presence with a moon-like staff. Summon star-shaped magic at long range to strike a single nightmare from afar.", stats: { dmg: 38, range: 90, hp: 135, speed: 5.2, cooldown: 18 } },
  attacker: { name: "The Attacker", tagline: "Crescent scythe hunter",     description: "Close-range combat master with a moon-shaped scythe. Slash through nightmares at melee range with fierce precision.", stats: { dmg: 72, range: 32, hp: 125, speed: 5.4, cooldown: 15 } },
  defender: { name: "The Defender", tagline: "Moon bubble sentinel",       description: "A fist-fighter wrapped in a glowing moon shield. Collect moon orbs to restore shield strength while standing between nightmares and the moon.", stats: { dmg: 32, range: 28, hp: 185, speed: 4.5, cooldown: 19 } },
  healer:   { name: "The Healer",   tagline: "Nightmare seer",            description: "Sees nightmares before they arrive. Fire test-tube bottles that explode in clusters and cleanse grouped enemies in close range.", stats: { dmg: 28, range: 90, hp: 220, speed: 5.0, cooldown: 17 } },
};

const LEVEL_WAVES = [2, 3, 5];

const INTRO_LINES = [
  "Our city lives beneath eternal darkness, with only the moon to cast its light.",
  "Grand seaglass towers and crescent-lined streets glow by the breath of moondust orbs.",
  "Corruption has spread through our town. Nightmares formed from pain and doubt now attack the people.",
  "The moon's light is fading as hatred and agony leak into our dreams.",
  "Children train to master their dreams, knowing that one day they will see the future with the moon's guidance.",
  "You are part of the rescue crew. Choose your path and save the moon before the town is lost.",
];

function DreamersGame() {
  const [phase, setPhase] = useState<Phase>("title");
  const [introIdx, setIntroIdx] = useState(0);
  const [role, setRole] = useState<RoleKey>("leader");

  return (
    <main className="min-h-screen w-full overflow-hidden text-foreground">
      <Starfield />
      {phase === "title" && <TitleScreen onStart={() => setPhase("intro")} />}
      {phase === "intro" && (
        <IntroScreen
          line={INTRO_LINES[introIdx]} index={introIdx} total={INTRO_LINES.length}
          onNext={() => { if (introIdx + 1 >= INTRO_LINES.length) setPhase("role"); else setIntroIdx(introIdx + 1); }}
          onSkip={() => setPhase("role")}
        />
      )}
      {phase === "role" && <RoleSelect selected={role} onSelect={setRole} onConfirm={() => setPhase("play")} />}
      {phase === "play" && <GameScene role={role} onWin={() => setPhase("win")} onLose={() => setPhase("lose")} onChangeRole={() => setPhase("role")} />}
      {(phase === "win" || phase === "lose") && (
        <EndScreen
          win={phase === "win"} role={role}
          onRetry={() => setPhase("play")}
          onMenu={() => { setIntroIdx(0); setPhase("title"); }}
        />
      )}
    </main>
  );
}

/* ---------------- starfield ---------------- */
function Starfield() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10">
      <div className="absolute inset-0 opacity-80" style={{
        backgroundImage:
          "radial-gradient(1px 1px at 12% 22%, white, transparent), " +
          "radial-gradient(1px 1px at 78% 15%, #b9d4ff, transparent), " +
          "radial-gradient(1.5px 1.5px at 34% 68%, white, transparent), " +
          "radial-gradient(1px 1px at 65% 80%, #8fb6ff, transparent), " +
          "radial-gradient(1px 1px at 88% 55%, white, transparent), " +
          "radial-gradient(1px 1px at 9% 80%, white, transparent), " +
          "radial-gradient(1px 1px at 48% 30%, #cfe4ff, transparent), " +
          "radial-gradient(1px 1px at 22% 50%, white, transparent)",
      }} />
    </div>
  );
}

/* ---------------- title ---------------- */
function TitleScreen({ onStart }: { onStart: () => void }) {
  return (
    <section className="relative flex min-h-screen items-center justify-center px-6 py-12">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(188,214,255,0.18),transparent_18%),radial-gradient(circle_at_40%_70%,rgba(130,170,255,0.12),transparent_24%),radial-gradient(circle_at_80%_90%,rgba(180,215,255,0.08),transparent_18%)]" />
      <div className="relative z-10 w-full max-w-[960px] aspect-[1/1] rounded-[2rem] px-10 py-12 screen-shell overflow-hidden">
        <div className="star-border">
          <span className="star-accent" />
          <span className="star-accent" />
          <span className="star-accent" />
          <span className="star-accent" />
        </div>
        <div className="absolute inset-x-0 top-0 h-24 bg-[radial-gradient(circle_at_top,_rgba(255,255,255,0.15),transparent_40%)]" />
        <div className="relative flex h-full flex-col items-center justify-center text-center">
          <div className="mb-8 flex items-center justify-center">
            <div className="animate-float moon-glow h-24 w-24 rounded-full bg-[radial-gradient(circle_at_30%_30%,rgba(234,243,255,0.95),rgba(91,122,203,0.7)_40%,rgba(8,18,55,0.96)_90%)] shadow-[0_0_120px_rgba(138,180,255,0.28)]" />
          </div>
          <h1 className="font-display text-5xl md:text-7xl text-white text-glow tracking-[0.18em]">MOONLIGHT GUARDIANS</h1>
          <p className="mt-4 max-w-xl text-base md:text-lg leading-relaxed text-slate-100/90">
            A city of eternal darkness, lit only by the moon and moondust orbs. Your crew protects the light, the dreams, and the future of every child.
          </p>
          <button onClick={onStart}
            className="mt-10 inline-flex items-center justify-center rounded-full border border-white/25 bg-white/10 px-12 py-3 text-sm uppercase tracking-[0.35em] text-white transition hover:bg-white/15 hover:scale-[1.03]">
            BEGIN YOUR WATCH
          </button>
          <div className="mt-6 flex flex-wrap justify-center gap-3 text-[11px] uppercase tracking-[0.35em] text-slate-200/70">
            <span>Moon & Stars</span>
            <span>Seaglass city</span>
            <span>Your crew awaits</span>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- intro ---------------- */
function IntroScreen({ line, index, total, onNext, onSkip }: { line: string; index: number; total: number; onNext: () => void; onSkip: () => void }) {
  return (
    <section className="relative flex min-h-screen items-center justify-center px-6 py-12">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_15%_20%,rgba(255,255,255,0.12),transparent_12%),radial-gradient(circle_at_80%_18%,rgba(180,210,255,0.1),transparent_15%)]" />
      <div className="relative z-10 w-full max-w-[860px] rounded-[2rem] px-8 py-10 dialogue-panel overflow-hidden">
        <div className="dialogue-border" />
        <div className="star-border">
          <span className="star-accent" />
          <span className="star-accent" />
          <span className="star-accent" />
          <span className="star-accent" />
        </div>
        <div className="relative text-center">
          <div className="mb-6 text-xs uppercase tracking-[0.4em] text-primary/70">The Council Speaks · {index + 1} / {total}</div>
          <p key={index} className="font-display text-2xl md:text-4xl leading-relaxed text-white text-glow">"{line}"</p>
          <div className="mt-10 flex flex-col gap-3 sm:flex-row items-center justify-center">
            <button onClick={onNext} className="font-display rounded-full border border-white/25 bg-white/10 px-8 py-2.5 text-xs uppercase tracking-[0.35em] text-white transition hover:bg-white/15">CONTINUE</button>
            <button onClick={onSkip} className="text-xs uppercase tracking-[0.35em] text-slate-200 hover:text-white transition">Skip</button>
          </div>
          <div className="mt-6 text-[12px] uppercase tracking-[0.35em] text-slate-200/60">Wind through arched streets. Moonlight on stone and glass.</div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- role select ---------------- */
function RoleSelect({ selected, onSelect, onConfirm }: { selected: RoleKey; onSelect: (r: RoleKey) => void; onConfirm: () => void }) {
  return (
    <section className="relative min-h-screen px-6 py-16">
      <div className="mx-auto max-w-5xl">
        <h2 className="font-display text-center text-4xl text-primary text-glow">Choose your role</h2>
        <p className="mt-3 text-center italic text-muted-foreground">Choose your role in the rescue crew. Your dream mastery will shape how the moon survives and how the city heals.</p>
        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {(Object.keys(ROLES) as RoleKey[]).map((key) => {
            const r = ROLES[key]; const active = selected === key;
            return (
              <button key={key} onClick={() => onSelect(key)}
                className={`text-left rounded-2xl border p-6 transition backdrop-blur ${active ? "border-primary/70 bg-primary/15 moon-glow scale-[1.02]" : "border-border bg-card/40 hover:border-primary/40 hover:bg-card/70"}`}>
                <div className="font-display text-2xl text-primary">{r.name}</div>
                <div className="text-xs uppercase tracking-[0.25em] text-muted-foreground mt-1">{r.tagline}</div>
                <p className="mt-3 text-foreground/90">{r.description}</p>
                <div className="mt-4">
                  <div className="mb-1 flex justify-between text-[10px] uppercase tracking-widest text-muted-foreground">
                    <span>HP</span><span>{r.stats.hp}</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div className="h-full bg-[linear-gradient(90deg,#75a7ff,#d7f1ff)]" style={{ width: `${Math.min(100, Math.max(8, (r.stats.hp / 220) * 100))}%` }} />
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-4 gap-2 text-[10px] uppercase tracking-widest text-muted-foreground">
                  <Stat label="Power" v={r.stats.dmg / 70} />
                  <Stat label="Reach" v={r.stats.range / 80} />
                  <Stat label="Light" v={r.stats.hp / 220} />
                  <Stat label="Pace"  v={r.stats.speed / 6} />
                </div>
              </button>
            );
          })}
        </div>
        <div className="mt-10 flex justify-center">
          <button onClick={onConfirm}
            className="font-display rounded-full border border-primary/50 bg-primary/20 px-12 py-3 text-sm tracking-[0.3em] text-primary hover:bg-primary/30 transition hover:scale-105">
            STEP INTO THE NIGHT
          </button>
        </div>
      </div>
    </section>
  );
}

function Stat({ label, v }: { label: string; v: number }) {
  return (
    <div>
      <div className="mb-1">{label}</div>
      <div className="h-1 rounded bg-muted overflow-hidden">
        <div className="h-full bg-primary" style={{ width: `${Math.min(100, Math.max(8, v * 100))}%` }} />
      </div>
    </div>
  );
}

/* ---------------- FIRST-PERSON 3D SCENE ---------------- */
function GameScene({ role, onWin, onLose, onChangeRole }: { role: RoleKey; onWin: () => void; onLose: () => void; onChangeRole: () => void }) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const overlayRef = useRef<HTMLDivElement | null>(null);
  const [hud, setHud] = useState({ hp: 100, moon: 50, level: 1, wave: 1, wavesInLevel: LEVEL_WAVES[0], locked: false, shield: 0 });
  const [levelNotice, setLevelNotice] = useState({ level: 1, visible: true });
  const onWinRef = useRef(onWin); onWinRef.current = onWin;
  const onLoseRef = useRef(onLose); onLoseRef.current = onLose;

  useEffect(() => {
    setLevelNotice({ level: 1, visible: true });
    const mount = mountRef.current!;
    const width = () => mount.clientWidth;
    const height = () => mount.clientHeight;

    const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.35));
    renderer.setSize(width(), height());
    renderer.shadowMap.enabled = false;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.9;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    mount.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(role === "healer" ? 0x01030d : 0x050a1c, role === "healer" ? 0.028 : 0.038);
    scene.background = new THREE.Color(role === "healer" ? 0x01020a : 0x040814);

    const camera = new THREE.PerspectiveCamera(75, width() / height(), 0.1, 500);
    camera.position.set(0, 1.7, 0);
    scene.add(camera);

    // ---------- lighting ----------
    const ambient = new THREE.AmbientLight(role === "healer" ? 0x1a2752 : 0x4a6db0, role === "healer" ? 0.16 : 0.32);
    scene.add(ambient);
    const moonLight = new THREE.DirectionalLight(0xb8d4ff, role === "healer" ? 0.72 : 1.25);
    moonLight.position.set(40, 80, 30);
    moonLight.castShadow = false;
    moonLight.shadow.mapSize.set(512, 512);
    moonLight.shadow.camera.left = -60; moonLight.shadow.camera.right = 60;
    moonLight.shadow.camera.top = 60; moonLight.shadow.camera.bottom = -60;
    scene.add(moonLight);

    // ---------- the Moon ----------
    const moonGroup = new THREE.Group();
    const moonGeo = new THREE.SphereGeometry(8, 48, 48);
    const moonMat = new THREE.MeshBasicMaterial({ color: 0xeaf3ff });
    const moon = new THREE.Mesh(moonGeo, moonMat);
    moonGroup.add(moon);
    // halo sprite
    const haloCanvas = document.createElement("canvas");
    haloCanvas.width = haloCanvas.height = 256;
    const hctx = haloCanvas.getContext("2d")!;
    const grad = hctx.createRadialGradient(128, 128, 20, 128, 128, 128);
    grad.addColorStop(0, "rgba(200,225,255,0.85)");
    grad.addColorStop(0.4, "rgba(140,180,240,0.35)");
    grad.addColorStop(1, "rgba(140,180,240,0)");
    hctx.fillStyle = grad; hctx.fillRect(0, 0, 256, 256);
    const haloTex = new THREE.CanvasTexture(haloCanvas);
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex, color: 0xffffff, transparent: true, depthWrite: false }));
    halo.scale.set(30, 30, 1);
    moonGroup.add(halo);
    moonGroup.position.set(40, 45, -60);
    scene.add(moonGroup);

    function makeNoiseTexture(base = "#14234a", vein = "#6f93c8") {
      const canvas = document.createElement("canvas");
      canvas.width = canvas.height = 128;
      const ctx = canvas.getContext("2d")!;
      ctx.fillStyle = base;
      ctx.fillRect(0, 0, 256, 256);
      for (let i = 0; i < 320; i++) {
        const a = Math.random() * 0.16;
        ctx.fillStyle = i % 7 === 0 ? `rgba(185,215,255,${a})` : `rgba(0,0,0,${a})`;
        ctx.fillRect(Math.random() * 256, Math.random() * 256, 1 + Math.random() * 5, 1 + Math.random() * 5);
      }
      for (let i = 0; i < 10; i++) {
        ctx.strokeStyle = `${vein}${Math.floor(30 + Math.random() * 55).toString(16).padStart(2, "0")}`;
        ctx.lineWidth = 1 + Math.random() * 2;
        ctx.beginPath();
        ctx.moveTo(Math.random() * 256, Math.random() * 256);
        ctx.bezierCurveTo(Math.random() * 256, Math.random() * 256, Math.random() * 256, Math.random() * 256, Math.random() * 256, Math.random() * 256);
        ctx.stroke();
      }
      const tex = new THREE.CanvasTexture(canvas);
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(10, 10);
      tex.colorSpace = THREE.SRGBColorSpace;
      return tex;
    }

    // ---------- distorted dream ground ----------
    const groundGeo = new THREE.PlaneGeometry(210, 210, 40, 40);
    const groundPos = groundGeo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < groundPos.count; i++) {
      const x = groundPos.getX(i);
      const y = groundPos.getY(i);
      const dist = Math.sqrt(x * x + y * y);
      const ripple = Math.sin(x * 0.16) * 0.6 + Math.cos(y * 0.13) * 0.5 + Math.sin(dist * 0.22) * 0.9;
      groundPos.setZ(i, ripple);
    }
    groundGeo.computeVertexNormals();
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x0b1534,
      roughness: 0.72,
      metalness: 0.18,
      map: makeNoiseTexture("#0b1534", "#82a9df"),
      normalScale: new THREE.Vector2(0.35, 0.35),
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // ---------- warped dream architecture ----------
    const dreamObjects: { group: THREE.Group; phase: number; spin: THREE.Vector3; baseY: number }[] = [];
    const seaglassMat = new THREE.MeshPhysicalMaterial({
      color: 0x8ebfe8,
      roughness: 0.16,
      metalness: 0.08,
      transmission: 0.35,
      thickness: 0.8,
      transparent: true,
      opacity: 0.64,
      emissive: 0x132e58,
      emissiveIntensity: 0.35,
    });
    const darkStoneMat = new THREE.MeshStandardMaterial({
      color: 0x0a1022,
      roughness: 0.86,
      metalness: 0.22,
      map: makeNoiseTexture("#090f20", "#536b9e"),
    });
    const mirrorMat = new THREE.MeshPhysicalMaterial({
      color: 0xc9def7,
      roughness: 0.08,
      metalness: 0.6,
      transparent: true,
      opacity: 0.72,
      emissive: 0x3a6095,
      emissiveIntensity: 0.18,
    });
    function trackDreamObject(group: THREE.Group, baseY: number, float = true) {
      if (float) dreamObjects.push({ group, phase: Math.random() * Math.PI * 2, spin: new THREE.Vector3(Math.random() * 0.08, Math.random() * 0.12, Math.random() * 0.08), baseY });
      scene.add(group);
      return group;
    }
    function makeBrokenArch(x: number, z: number, ry = 0, scale = 1) {
      const g = new THREE.Group();
      const colGeo = new THREE.BoxGeometry(0.8, 7, 0.8);
      const left = new THREE.Mesh(colGeo, seaglassMat);
      left.position.set(-2.7, 0.8, 0); left.rotation.z = -0.16; left.castShadow = true; g.add(left);
      const right = new THREE.Mesh(colGeo, seaglassMat);
      right.position.set(2.4, 1.3, 0); right.rotation.z = 0.23; right.castShadow = true; g.add(right);
      const lintel = new THREE.Mesh(new THREE.BoxGeometry(6, 0.7, 0.7), seaglassMat);
      lintel.position.set(-0.1, 4.65, 0); lintel.rotation.z = 0.18; lintel.castShadow = true; g.add(lintel);
      const crescent = new THREE.Mesh(new THREE.TorusGeometry(0.75, 0.08, 10, 32, Math.PI * 1.35), mirrorMat);
      crescent.position.set(0, 5.7, 0.12); crescent.rotation.z = Math.PI / 2;
      g.add(crescent);
      g.position.set(x, 1.2 + Math.random() * 5, z); g.rotation.set(Math.random() * 0.5 - 0.25, ry, Math.random() * 0.4 - 0.2); g.scale.setScalar(scale);
      return trackDreamObject(g, g.position.y);
    }
    function makeFloatingSlab(x: number, y: number, z: number, w: number, h: number, d: number, mat = darkStoneMat) {
      const g = new THREE.Group();
      const slab = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      slab.castShadow = true; slab.receiveShadow = true; g.add(slab);
      g.position.set(x, y, z);
      g.rotation.set(Math.random() * 0.8 - 0.4, Math.random() * Math.PI, Math.random() * 0.8 - 0.4);
      return trackDreamObject(g, y);
    }
    function makeMirrorShard(x: number, y: number, z: number, s: number) {
      const g = new THREE.Group();
      const shard = new THREE.Mesh(new THREE.ConeGeometry(s, s * 3.2, 3), mirrorMat);
      shard.castShadow = true; shard.rotation.x = Math.PI / 2; g.add(shard);
      g.position.set(x, y, z);
      return trackDreamObject(g, y);
    }
    function makeDoor(x: number, y: number, z: number, ry: number, scale = 1) {
      const g = new THREE.Group();
      const frame = new THREE.Mesh(new THREE.BoxGeometry(2.4, 4.8, 0.38), darkStoneMat);
      frame.castShadow = true; g.add(frame);
      const opening = new THREE.Mesh(new THREE.BoxGeometry(1.55, 3.6, 0.42), new THREE.MeshBasicMaterial({ color: 0x050814 }));
      opening.position.z = 0.02; g.add(opening);
      const topMoon = new THREE.Mesh(new THREE.TorusGeometry(0.38, 0.04, 8, 24, Math.PI * 1.35), mirrorMat);
      topMoon.position.set(0, 2.05, 0.28); topMoon.rotation.z = Math.PI / 2; g.add(topMoon);
      const backLight = new THREE.PointLight(0x6fa8ff, 0.9, 10, 2);
      backLight.position.set(0, 0.3, 0.4); g.add(backLight);
      g.position.set(x, y, z); g.rotation.set(Math.random() * 0.18, ry, Math.random() * 0.22); g.scale.setScalar(scale);
      return trackDreamObject(g, y);
    }
    for (let i = 0; i < 7; i++) makeBrokenArch(Math.cos(i) * (18 + i * 3), Math.sin(i * 1.7) * 28, i * 0.9, 0.8 + Math.random() * 0.5);
    for (let i = 0; i < 20; i++) makeFloatingSlab((Math.random() - 0.5) * 72, 3 + Math.random() * 13, (Math.random() - 0.5) * 72, 2 + Math.random() * 8, 0.25 + Math.random() * 0.8, 1 + Math.random() * 5, i % 4 === 0 ? seaglassMat : darkStoneMat);
    for (let i = 0; i < 18; i++) makeMirrorShard((Math.random() - 0.5) * 80, 2 + Math.random() * 18, (Math.random() - 0.5) * 80, 0.35 + Math.random() * 0.7);
    makeDoor(0, 1.8, -24, 0, 1.3);
    makeDoor(-18, 6.5, 10, -0.7, 0.9);
    makeDoor(23, 9.5, 18, 0.65, 1.1);

    const localDreamCluster = new THREE.Group();
    const clusterCount = 72;
    const shardGeo = new THREE.ConeGeometry(0.22, 1.25, 3);
    const shardMat = new THREE.MeshBasicMaterial({ color: 0x9fcaff, transparent: true, opacity: 0.72 });
    const orbClusterGeo = new THREE.SphereGeometry(0.12, 10, 10);
    const orbClusterMat = new THREE.MeshBasicMaterial({ color: 0xdcecff, transparent: true, opacity: 0.9 });
    const shardCluster = new THREE.InstancedMesh(shardGeo, shardMat, clusterCount);
    const orbCluster = new THREE.InstancedMesh(orbClusterGeo, orbClusterMat, clusterCount);
    const matrix = new THREE.Matrix4();
    const pos = new THREE.Vector3();
    const quat = new THREE.Quaternion();
    const scl = new THREE.Vector3();
    const euler = new THREE.Euler();
    for (let i = 0; i < clusterCount; i++) {
      const angle = i * 2.399;
      const radius = 8 + (i % 18) * 0.78;
      const y = 1.1 + (i % 9) * 0.52 + Math.random() * 1.2;
      pos.set(Math.cos(angle) * radius, y, Math.sin(angle) * radius);
      euler.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
      quat.setFromEuler(euler);
      const size = 0.55 + Math.random() * 1.15;
      scl.set(size, size, size);
      matrix.compose(pos, quat, scl);
      shardCluster.setMatrixAt(i, matrix);
      pos.y += 0.35 + Math.random() * 1.2;
      scl.setScalar(0.75 + Math.random() * 1.4);
      matrix.compose(pos, quat, scl);
      orbCluster.setMatrixAt(i, matrix);
    }
    shardCluster.instanceMatrix.needsUpdate = true;
    orbCluster.instanceMatrix.needsUpdate = true;
    localDreamCluster.add(shardCluster, orbCluster);
    scene.add(localDreamCluster);

    // ---------- floating moondust orbs ----------
    const lamps: { mesh: THREE.Mesh; light: THREE.PointLight; base: number }[] = [];
    function makeLamp(x: number, z: number, y = 2.8) {
      const g = new THREE.Group();
      const orb = new THREE.Mesh(
        new THREE.SphereGeometry(0.42, 24, 24),
        new THREE.MeshPhysicalMaterial({ color: 0xeaf3ff, roughness: 0.08, metalness: 0.05, transmission: 0.35, transparent: true, opacity: 0.86, emissive: 0xa9c8ff, emissiveIntensity: 2.6 })
      );
      g.add(orb);
      const halo = new THREE.Mesh(new THREE.SphereGeometry(0.95, 20, 20), new THREE.MeshBasicMaterial({ color: 0x89bfff, transparent: true, opacity: 0.08, depthWrite: false }));
      g.add(halo);
      const light = new THREE.PointLight(0xa9c8ff, 1.35, 13, 2);
      if (lamps.length % 3 === 0) g.add(light);
      g.position.set(x, y, z);
      trackDreamObject(g, y, true);
      lamps.push({ mesh: orb, light, base: 2.5 });
    }
    for (let i = 0; i < 18; i++) {
      const a = i * 1.73;
      const r = 8 + (i % 5) * 7;
      makeLamp(Math.cos(a) * r, Math.sin(a) * r, 2.5 + Math.random() * 4);
    }

    // ---------- moon flower patches ----------
    const flowerMat = new THREE.MeshStandardMaterial({ color: 0xd6e4ff, emissive: 0x6a90d6, emissiveIntensity: 0.7 });
    for (let i = 0; i < 40; i++) {
      const f = new THREE.Mesh(new THREE.SphereGeometry(0.18, 6, 6), flowerMat);
      const angle = Math.random() * Math.PI * 2;
      const r = 6 + Math.random() * 30;
      f.position.set(Math.cos(angle) * r, 0.18, Math.sin(angle) * r);
      scene.add(f);
    }

    // ---------- player ----------
    const r = ROLES[role];
    const player = {
      pos: new THREE.Vector3(0, 1.7, 0),
      vel: new THREE.Vector3(),
      yaw: 0, pitch: 0,
      hp: r.stats.hp,
      cool: 0,
      shield: role === "defender" ? 120 : 0,
      shieldMax: role === "defender" ? 120 : 0,
    };

    const defenderBubble = new THREE.Mesh(
      new THREE.SphereGeometry(1.75, 28, 28),
      new THREE.MeshPhongMaterial({ color: 0x9bdaff, transparent: true, opacity: 0.16, emissive: 0x79c4ff, emissiveIntensity: 0.8, side: THREE.DoubleSide })
    );
    defenderBubble.visible = role === "defender";
    defenderBubble.position.copy(player.pos);
    scene.add(defenderBubble);

    const healerVision = new THREE.Mesh(
      new THREE.RingGeometry(0.75, 10.4, 64),
      new THREE.MeshBasicMaterial({ color: 0x80d8ff, transparent: true, opacity: 0.08, side: THREE.DoubleSide })
    );
    healerVision.rotation.x = -Math.PI / 2;
    healerVision.visible = role === "healer";
    healerVision.position.y = 0.12;
    scene.add(healerVision);

    const firstPersonScythe = new THREE.Group();
    let scytheSwing = 0;
    if (role === "attacker") {
      const handleMat = new THREE.MeshStandardMaterial({ color: 0x1a1730, roughness: 0.38, metalness: 0.35, emissive: 0x221448, emissiveIntensity: 0.5 });
      const bladeMat = new THREE.MeshStandardMaterial({ color: 0xe9dcff, roughness: 0.18, metalness: 0.28, emissive: 0xbd8fff, emissiveIntensity: 1.4 });
      const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.045, 1.45, 10), handleMat);
      grip.position.set(0, -0.2, 0);
      grip.rotation.z = -0.2;
      firstPersonScythe.add(grip);
      const lowerGrip = new THREE.Mesh(new THREE.SphereGeometry(0.07, 12, 12), bladeMat);
      lowerGrip.position.set(-0.14, -0.86, 0);
      firstPersonScythe.add(lowerGrip);
      const crescentBlade = new THREE.Mesh(new THREE.TorusGeometry(0.38, 0.052, 18, 52, Math.PI * 1.28), bladeMat);
      crescentBlade.position.set(0.19, 0.58, -0.03);
      crescentBlade.rotation.set(Math.PI / 2, 0.18, -0.65);
      firstPersonScythe.add(crescentBlade);
      const bladeTip = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.22, 12), bladeMat);
      bladeTip.position.set(0.51, 0.72, -0.03);
      bladeTip.rotation.z = -1.1;
      firstPersonScythe.add(bladeTip);
      const scytheLight = new THREE.PointLight(0xbe8cff, 0.85, 4, 2);
      scytheLight.position.set(0.1, 0.3, 0);
      firstPersonScythe.add(scytheLight);
      firstPersonScythe.position.set(0.62, -0.58, -1.05);
      firstPersonScythe.rotation.set(-0.34, -0.34, -0.1);
      camera.add(firstPersonScythe);
    }

    // ---------- crew companions (visible character models you walk with) ----------
    type Character = {
      group: THREE.Group;
      basePos: THREE.Vector3;
      offset: THREE.Vector3;
      phase: number;
    };
    function makeHumanoid(color: number, accent: number, glow: number) {
      const g = new THREE.Group();
      const clothMat = new THREE.MeshStandardMaterial({ color, roughness: 0.58, metalness: 0.08, emissive: glow, emissiveIntensity: 0.2 });
      const skinMat = new THREE.MeshStandardMaterial({ color: accent, roughness: 0.42, emissive: glow, emissiveIntensity: 0.12 });
      const hairMat = new THREE.MeshStandardMaterial({ color: 0x172033, roughness: 0.7, emissive: 0x071124, emissiveIntensity: 0.2 });
      const bootMat = new THREE.MeshStandardMaterial({ color: 0x091126, roughness: 0.75 });
      const eyeMat = new THREE.MeshBasicMaterial({ color: 0x061024 });

      const torso = new THREE.Mesh(new THREE.BoxGeometry(0.82, 1.05, 0.42), clothMat);
      torso.position.y = 1.18; torso.castShadow = true; g.add(torso);
      const tunic = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.5, 0.62, 12), clothMat);
      tunic.position.y = 0.58; tunic.castShadow = true; g.add(tunic);

      const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.11, 0.16, 10), skinMat);
      neck.position.y = 1.79; g.add(neck);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.29, 18, 18), skinMat);
      head.position.y = 2.08; head.scale.set(0.9, 1.08, 0.86); head.castShadow = true; g.add(head);
      const hair = new THREE.Mesh(new THREE.SphereGeometry(0.31, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), hairMat);
      hair.position.y = 2.18; hair.scale.set(1.0, 0.72, 0.95); hair.rotation.x = 0.12; g.add(hair);

      const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 6), eyeMat);
      eyeL.position.set(-0.09, 2.1, 0.245); g.add(eyeL);
      const eyeR = eyeL.clone();
      eyeR.position.x = 0.09; g.add(eyeR);

      const armGeo = new THREE.CylinderGeometry(0.075, 0.085, 0.88, 8);
      const la = new THREE.Mesh(armGeo, clothMat); la.position.set(-0.52, 1.12, 0); la.rotation.z = 0.32; la.castShadow = true; g.add(la);
      const ra = new THREE.Mesh(armGeo, clothMat); ra.position.set(0.52, 1.12, 0); ra.rotation.z = -0.32; ra.castShadow = true; g.add(ra);
      const handGeo = new THREE.SphereGeometry(0.09, 10, 10);
      const lh = new THREE.Mesh(handGeo, skinMat); lh.position.set(-0.66, 0.68, 0); g.add(lh);
      const rh = new THREE.Mesh(handGeo, skinMat); rh.position.set(0.66, 0.68, 0); g.add(rh);

      const legGeo = new THREE.CylinderGeometry(0.105, 0.12, 0.76, 8);
      const ll = new THREE.Mesh(legGeo, clothMat); ll.position.set(-0.2, 0.34, 0); ll.castShadow = true; g.add(ll);
      const rl = new THREE.Mesh(legGeo, clothMat); rl.position.set(0.2, 0.34, 0); rl.castShadow = true; g.add(rl);
      const bootL = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.1, 0.34), bootMat); bootL.position.set(-0.2, 0.02, 0.06); g.add(bootL);
      const bootR = bootL.clone(); bootR.position.x = 0.2; g.add(bootR);

      const crescent = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.04, 8, 24, Math.PI * 1.3),
        new THREE.MeshStandardMaterial({ color: 0xeaf3ff, emissive: 0xa9c8ff, emissiveIntensity: 1.5 }));
      crescent.position.set(0, 1.42, 0.25); crescent.rotation.x = Math.PI / 2;
      g.add(crescent);
      const gl = new THREE.PointLight(glow, 0.7, 5, 2);
      gl.position.set(0, 1.4, 0); g.add(gl);
      return g;
    }
    const companions: Character[] = [];
    void companions;
    const crewColors: Record<RoleKey, [number, number, number]> = {
      leader:   [0x2a4f8c, 0xdfe7f5, 0x88b6ff],
      attacker: [0x4a2c6a, 0xe2d9f0, 0xc78cff],
      defender: [0x1a3a5c, 0xc9d6ee, 0x6fa8e0],
      healer:   [0x2c5c5e, 0xd8eef0, 0x8ce0d6],
    };
    function makeCompanion(role: RoleKey) {
      const [c1, c2, gl] = crewColors[role];
      const ch = makeHumanoid(c1, c2, gl);
      const detailMat = new THREE.MeshStandardMaterial({ color: 0xeaf3ff, emissive: 0x89b7ff, emissiveIntensity: 1.4, roughness: 0.25 });
      if (role === "leader") {
        const staff = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.5, 8), detailMat);
        staff.position.set(-0.35, 1.95, 0); staff.rotation.z = -0.18; ch.add(staff);
        const moonCrest = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.05, 10, 24, Math.PI * 1.35), detailMat);
        moonCrest.position.set(-0.35, 2.8, 0); moonCrest.rotation.x = Math.PI / 2; ch.add(moonCrest);
        const starTip = new THREE.Mesh(new THREE.OctahedronGeometry(0.14), new THREE.MeshStandardMaterial({ color: 0xeaf3ff, emissive: 0xb9dcff, emissiveIntensity: 1.7, roughness: 0.22 }));
        starTip.position.set(-0.35, 3.12, 0); ch.add(starTip);
      }
      if (role === "attacker") {
        const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 1.8, 8), detailMat);
        handle.position.set(0.45, 1.35, 0); handle.rotation.z = -0.4; ch.add(handle);
        const blade = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.08, 14, 40, Math.PI * 1.18), detailMat);
        blade.position.set(0.8, 1.25, -0.05); blade.rotation.x = Math.PI / 2; blade.rotation.z = 0.32; ch.add(blade);
      }
      if (role === "defender") {
        const shield = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.52, 0.18, 24), detailMat);
        shield.position.set(0.72, 1.35, 0.08); shield.rotation.y = Math.PI / 6; ch.add(shield);
        const brace = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.04, 8, 20), new THREE.MeshStandardMaterial({ color: 0xafd6ff, emissive: 0x92bfff, emissiveIntensity: 1.2, roughness: 0.2 }));
        brace.position.set(0.78, 1.18, -0.02); brace.rotation.x = Math.PI / 2; ch.add(brace);
      }
      if (role === "healer") {
        const glass = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.4, 12), new THREE.MeshPhysicalMaterial({ color: 0xdfefff, transparent: true, opacity: 0.9, transmission: 0.6, roughness: 0.18, metalness: 0.06 }));
        glass.position.set(-0.22, 1.85, 0); glass.rotation.z = -0.08; ch.add(glass);
        const top = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 12), new THREE.MeshBasicMaterial({ color: 0xa3d6ff }));
        top.position.set(-0.22, 2.5, 0); ch.add(top);
        const liquid = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 1.1, 12), new THREE.MeshStandardMaterial({ color: 0x79d4ff, emissive: 0x83d9ff, emissiveIntensity: 1.6, roughness: 0.12 }));
        liquid.position.set(-0.22, 1.82, 0); liquid.rotation.z = -0.08; ch.add(liquid);
      }
      return ch;
    }
    void makeCompanion;

    // ---------- no townspeople in the dream ----------
    const townies: Character[] = [];
    void townies;

    // ---------- nightmares ----------
    type NightmareKind = "stalker" | "leech" | "eclipse";
    type Nightmare = { group: THREE.Group; hp: number; speed: number; light: THREE.PointLight; kind: NightmareKind };
    const nightmareLooks: Record<NightmareKind, { body: number; veil: number; glow: number; eye: number }> = {
      stalker: { body: 0x160720, veil: 0x5b123f, glow: 0xff4a78, eye: 0xff4a78 },
      leech: { body: 0x2a0615, veil: 0x8d1735, glow: 0xff2f5f, eye: 0xffd1dc },
      eclipse: { body: 0x050514, veil: 0x18245a, glow: 0x6d7dff, eye: 0xc5d1ff },
    };
    function makeNightmare(kind: NightmareKind) {
      const g = new THREE.Group();
      const look = nightmareLooks[kind];
      const ghostMat = new THREE.MeshStandardMaterial({
        color: role === "healer" ? 0xeafff4 : look.body,
        roughness: 0.92,
        emissive: role === "healer" ? 0x68ffd7 : look.glow,
        emissiveIntensity: role === "healer" ? 2.8 : 0.65,
        transparent: true,
        opacity: role === "healer" ? 0.92 : 0.62,
        depthWrite: false,
      });
      const veilMat = new THREE.MeshBasicMaterial({
        color: role === "healer" ? 0x9fffea : look.veil,
        transparent: true,
        opacity: role === "healer" ? 0.5 : 0.18,
        depthWrite: false,
        side: THREE.DoubleSide,
      });
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.42, 16, 16), ghostMat);
      head.position.y = 2.05; head.scale.set(1, 1.15, 0.82); g.add(head);
      const veil = new THREE.Mesh(new THREE.ConeGeometry(0.82, 1.85, 20, 1, true), veilMat);
      veil.position.y = 1.05; veil.rotation.x = Math.PI; g.add(veil);
      const core = new THREE.Mesh(new THREE.SphereGeometry(0.5, 14, 14), ghostMat);
      core.position.y = 1.2; core.scale.set(0.75, 1.3, 0.58); g.add(core);
      if (kind === "leech") {
        head.scale.set(0.78, 1.45, 0.72);
        veil.scale.set(0.62, 1.25, 0.62);
        core.scale.set(0.58, 1.72, 0.46);
      }
      if (kind === "eclipse") {
        head.scale.set(1.28, 0.88, 1.08);
        veil.scale.set(1.35, 0.82, 1.35);
        core.scale.set(1.25, 0.9, 1.12);
      }

      const eyeMat = new THREE.MeshBasicMaterial({ color: role === "healer" ? 0x05000c : look.eye });
      const e1 = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 8), eyeMat); e1.position.set(-0.13, 2.12, 0.31); g.add(e1);
      const e2 = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 8), eyeMat); e2.position.set( 0.13, 2.12, 0.31); g.add(e2);

      if (kind === "leech") {
        const thorns = new THREE.Mesh(
          new THREE.TorusGeometry(0.42, 0.035, 8, 24),
          new THREE.MeshBasicMaterial({ color: role === "healer" ? 0x05000c : 0xff4a78, transparent: true, opacity: 0.85 })
        );
        thorns.position.y = 1.52;
        thorns.rotation.x = Math.PI / 2;
        g.add(thorns);
        const fangMat = new THREE.MeshBasicMaterial({ color: role === "healer" ? 0x05000c : 0xffd1dc, transparent: true, opacity: 0.9 });
        for (let i = 0; i < 6; i++) {
          const fang = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.38, 8), fangMat);
          const a = i * Math.PI / 3;
          fang.position.set(Math.cos(a) * 0.48, 1.7 + (i % 2) * 0.18, Math.sin(a) * 0.48);
          fang.rotation.set(Math.PI / 2, 0, -a);
          g.add(fang);
        }
        const siphon = new THREE.Mesh(
          new THREE.CylinderGeometry(0.02, 0.055, 1.4, 8),
          new THREE.MeshBasicMaterial({ color: role === "healer" ? 0x05000c : 0xff2f5f, transparent: true, opacity: 0.72 })
        );
        siphon.position.set(0, 0.85, 0.58);
        siphon.rotation.x = Math.PI / 2;
        g.add(siphon);
      }
      if (kind === "eclipse") {
        const eclipseRing = new THREE.Mesh(
          new THREE.TorusGeometry(0.72, 0.045, 10, 36),
          new THREE.MeshBasicMaterial({ color: role === "healer" ? 0x05000c : 0x8794ff, transparent: true, opacity: 0.76 })
        );
        eclipseRing.position.y = 2.1;
        eclipseRing.rotation.x = Math.PI / 2;
        g.add(eclipseRing);
        const outerRing = new THREE.Mesh(
          new THREE.TorusGeometry(1.02, 0.035, 10, 44),
          new THREE.MeshBasicMaterial({ color: role === "healer" ? 0x05000c : 0x2d377e, transparent: true, opacity: 0.62 })
        );
        outerRing.position.y = 1.36;
        outerRing.rotation.set(Math.PI / 2, 0.35, 0);
        g.add(outerRing);
        const darkMoon = new THREE.Mesh(
          new THREE.SphereGeometry(0.18, 14, 14),
          new THREE.MeshBasicMaterial({ color: role === "healer" ? 0x05000c : 0x02030b, transparent: true, opacity: 0.92 })
        );
        darkMoon.position.set(0.86, 2.1, 0);
        g.add(darkMoon);
      }

      const tendrilGeo = new THREE.CylinderGeometry(0.035, 0.01, 1.05, 7);
      for (let i = 0; i < 5; i++) {
        const tendril = new THREE.Mesh(tendrilGeo, ghostMat);
        tendril.position.set((i - 2) * 0.22, 0.42, Math.sin(i) * 0.12);
        tendril.rotation.z = (i - 2) * 0.16;
        tendril.rotation.x = Math.sin(i * 1.7) * 0.22;
        g.add(tendril);
      }
      if (role === "healer") {
        const farBeacon = new THREE.Mesh(
          new THREE.SphereGeometry(1.25, 20, 20),
          new THREE.MeshBasicMaterial({ color: 0xb8fff0, transparent: true, opacity: 0.18, depthWrite: false, wireframe: true })
        );
        farBeacon.position.y = 1.35;
        g.add(farBeacon);
        const sightMark = new THREE.Mesh(
          new THREE.RingGeometry(0.62, 0.86, 32),
          new THREE.MeshBasicMaterial({ color: 0xeafff4, transparent: true, opacity: 0.72, depthWrite: false, side: THREE.DoubleSide })
        );
        sightMark.position.y = 2.6;
        sightMark.rotation.x = Math.PI / 2;
        g.add(sightMark);
      }
      const light = new THREE.PointLight(role === "healer" ? 0xb8fff0 : look.glow, role === "healer" ? 2.6 : 0.45, role === "healer" ? 34 : 5, 2);
      light.position.set(0, 2.1, 0); g.add(light);
      return { group: g, hp: 30, speed: 1.05, light, kind };
    }
    const nightmares: Nightmare[] = [];
    function monstersForWave(level: number, wave: number) {
      void level; void wave;
      return 4;
    }
    function chooseNightmareKind(level: number, wave: number, slot: number): NightmareKind {
      if (level >= 3 && (slot + wave) % 2 === 0) return "eclipse";
      if (level >= 2 && (slot + wave) % 3 === 0) return "leech";
      if (level >= 3 && slot === 3) return "leech";
      return "stalker";
    }
    function spawnNightmare(level: number, wave: number, slot: number) {
      const kind = chooseNightmareKind(level, wave, slot);
      const n = makeNightmare(kind);
      const levelPower = 1 + (level - 1) * 0.14;
      const angle = Math.random() * Math.PI * 2;
      const radius = 25 + Math.random() * 10;
      n.group.position.set(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
      n.hp = Math.round((kind === "eclipse" ? 66 : kind === "leech" ? 44 : 30) * levelPower + wave * 2);
      n.speed = (kind === "leech" ? 1.22 : kind === "eclipse" ? 0.68 : 0.92) * (1 + (level - 1) * 0.07);
      scene.add(n.group);
      nightmares.push(n);
    }

    // ---------- moondust orbs (projectiles) ----------
    type Orb = { mesh: THREE.Object3D; vel: THREE.Vector3; life: number; light: THREE.PointLight };
    type PickupOrb = { mesh: THREE.Mesh; light: THREE.PointLight; life: number };
    const orbs: Orb[] = [];
    const pickups: PickupOrb[] = [];
    const orbGeo = new THREE.SphereGeometry(0.15, 12, 12);
    const orbMat = new THREE.MeshBasicMaterial({ color: 0xeaf3ff });
    const pickupGeo = new THREE.SphereGeometry(0.18, 14, 14);
    const pickupMat = new THREE.MeshPhysicalMaterial({ color: 0xcff4ff, emissive: 0x90d8ff, emissiveIntensity: 1.8, transparent: true, opacity: 0.86, roughness: 0.12, metalness: 0.14 });
    let pickupT = role === "defender" ? 2.2 : Number.POSITIVE_INFINITY;
    function makeStarMesh(size: number, material: THREE.Material) {
      const shape = new THREE.Shape();
      for (let i = 0; i < 10; i++) {
        const a = -Math.PI / 2 + i * Math.PI / 5;
        const r = i % 2 === 0 ? size : size * 0.42;
        const x = Math.cos(a) * r;
        const y = Math.sin(a) * r;
        if (i === 0) shape.moveTo(x, y);
        else shape.lineTo(x, y);
      }
      shape.closePath();
      return new THREE.Mesh(new THREE.ShapeGeometry(shape), material);
    }
    function spawnPickupOrb() {
      const mesh = new THREE.Mesh(pickupGeo, pickupMat);
      const angle = Math.random() * Math.PI * 2;
      const r = 14 + Math.random() * 25;
      mesh.position.set(Math.cos(angle) * r, 0.2, Math.sin(angle) * r);
      const light = new THREE.PointLight(0x7fd7ff, 1.2, 8, 2);
      light.position.set(0, 0.25, 0);
      mesh.add(light);
      scene.add(mesh);
      pickups.push({ mesh, light, life: 10 + Math.random() * 8 });
    }
    function fire() {
      if (player.cool > 0) return;
      player.cool = r.stats.cooldown;
      const dir = new THREE.Vector3();
      camera.getWorldDirection(dir);
      const origin = camera.position.clone();

      if (role === "attacker" || role === "defender") {
        if (role === "attacker") scytheSwing = 1;
        if (role === "defender" && pickups.length < 5) {
          pickupT = Math.min(pickupT, 0.8);
        }
        const range = role === "attacker" ? 2.6 : 1.8;
        const arc = role === "attacker" ? 1.4 : 1.1;
        const damage = r.stats.dmg;
        const center = origin.clone().add(dir.clone().multiplyScalar(1.2));
        let hitSomething = false;
        for (const n of nightmares) {
          const toN = n.group.position.clone().sub(origin);
          const dist = toN.length();
          if (dist < range) {
            const angle = dir.angleTo(toN.clone().normalize());
            if (angle < arc) {
              n.hp -= damage;
              hitSomething = true;
            }
          }
        }
        const sweep = new THREE.Mesh(
          new THREE.TorusGeometry(Math.max(0.7, range - 0.3), 0.06, 8, 32, Math.PI * 1.3),
          new THREE.MeshBasicMaterial({ color: role === "attacker" ? 0xd7c4ff : 0x9cc7ff, transparent: true, opacity: 0.45, side: THREE.DoubleSide })
        );
        sweep.position.copy(center);
        sweep.lookAt(origin.clone().add(dir));
        sweep.rotation.x += Math.PI / 2;
        scene.add(sweep);
        setTimeout(() => { scene.remove(sweep); }, 140);
        burst(center.clone(), role === "attacker" ? 0xd7c4ff : 0x9fd3ff, 18);
        if (!hitSomething) return;
        return;
      }

      if (role === "leader") {
        const target = nightmares.reduce((best, n) => {
          if (!best) return n;
          const current = n.group.position.distanceToSquared(origin);
          const bestDist = best.group.position.distanceToSquared(origin);
          return current < bestDist ? n : best;
        }, null as Nightmare | null);
        if (!target) return;
        const magic = new THREE.Group();
        const starMat = new THREE.MeshBasicMaterial({ color: 0xffe66f, transparent: true, opacity: 0.96, side: THREE.DoubleSide });
        const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.16, 0), new THREE.MeshStandardMaterial({ color: 0xffee88, emissive: 0xffd447, emissiveIntensity: 2.8, roughness: 0.18, transparent: true, opacity: 0.96 }));
        magic.add(core);
        for (let i = 0; i < 4; i++) {
          const star = makeStarMesh(0.16 - i * 0.018, starMat);
          star.position.set(Math.cos(i * Math.PI / 2) * 0.22, Math.sin(i * Math.PI / 2) * 0.16, 0);
          star.rotation.set(0.2 + i * 0.35, i * 0.4, i * 0.7);
          magic.add(star);
        }
        magic.position.copy(origin).add(dir.clone().multiplyScalar(0.8));
        const light = new THREE.PointLight(0xffdc45, 2.2, 10, 2);
        magic.add(light);
        scene.add(magic);
        const targetDir = target.group.position.clone().sub(origin).normalize();
        burst(magic.position.clone(), 0xffe66f, 12);
        orbs.push({ mesh: magic, vel: targetDir.multiplyScalar(28), life: r.stats.range / 28, light });
        return;
      }

      if (role === "healer") {
        const mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.85, 10), new THREE.MeshPhysicalMaterial({ color: 0x9ee7ff, emissive: 0x82d7ff, emissiveIntensity: 1.8, transparent: true, opacity: 0.92, roughness: 0.08, transmission: 0.55 }));
        mesh.position.copy(origin).add(dir.clone().multiplyScalar(0.8));
        mesh.rotation.copy(new THREE.Euler(-Math.PI / 2, 0, 0));
        const light = new THREE.PointLight(0x9ee7ff, 1.8, 7, 2);
        mesh.add(light);
        scene.add(mesh);
        orbs.push({ mesh, vel: dir.multiplyScalar(22), life: r.stats.range / 22, light });
        return;
      }
    }

    // ---------- particles ----------
    type P = { mesh: THREE.Mesh; vel: THREE.Vector3; life: number; max: number };
    const particles: P[] = [];
    const pGeo = new THREE.SphereGeometry(0.06, 6, 6);
    const pMatLight = new THREE.MeshBasicMaterial({ color: 0xcfe4ff, transparent: true });
    function burst(pos: THREE.Vector3, color = 0xcfe4ff, n = 18) {
      const mat = new THREE.MeshBasicMaterial({ color, transparent: true });
      for (let i = 0; i < n; i++) {
        const m = new THREE.Mesh(pGeo, mat);
        m.position.copy(pos);
        const v = new THREE.Vector3((Math.random() - 0.5) * 2, Math.random() * 2, (Math.random() - 0.5) * 2).multiplyScalar(2 + Math.random() * 3);
        scene.add(m);
        particles.push({ mesh: m, vel: v, life: 40 + Math.random() * 20, max: 60 });
      }
    }
    void pMatLight;

    // ---------- floating dust in air ----------
    const dustCount = 140;
    const dustGeo = new THREE.BufferGeometry();
    const dustPos = new Float32Array(dustCount * 3);
    for (let i = 0; i < dustCount; i++) {
      dustPos[i*3]   = (Math.random() - 0.5) * 60;
      dustPos[i*3+1] = Math.random() * 8 + 1;
      dustPos[i*3+2] = (Math.random() - 0.5) * 60;
    }
    dustGeo.setAttribute("position", new THREE.BufferAttribute(dustPos, 3));
    const dust = new THREE.Points(dustGeo, new THREE.PointsMaterial({ color: 0xa9c8ff, size: 0.08, transparent: true, opacity: 0.6, depthWrite: false }));
    scene.add(dust);

    // ---------- controls (pointer lock) ----------
    const keys = new Set<string>();
    const onKey = (e: KeyboardEvent, down: boolean) => {
      if (down) keys.add(e.key.toLowerCase()); else keys.delete(e.key.toLowerCase());
      if (down && e.key === " ") { e.preventDefault(); fire(); }
    };
    const onKD = (e: KeyboardEvent) => onKey(e, true);
    const onKU = (e: KeyboardEvent) => onKey(e, false);
    window.addEventListener("keydown", onKD);
    window.addEventListener("keyup", onKU);

    const onMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement !== renderer.domElement) return;
      player.yaw   -= e.movementX * 0.0036;
      player.pitch -= e.movementY * 0.0036;
      player.pitch = Math.max(-Math.PI/2 + 0.05, Math.min(Math.PI/2 - 0.05, player.pitch));
    };
    const onClick = () => {
      if (document.pointerLockElement !== renderer.domElement) {
        renderer.domElement.requestPointerLock();
      } else {
        fire();
      }
    };
    const onLockChange = () => {
      setHud(h => ({ ...h, locked: document.pointerLockElement === renderer.domElement }));
    };
    document.addEventListener("mousemove", onMouseMove);
    renderer.domElement.addEventListener("click", onClick);
    document.addEventListener("pointerlockchange", onLockChange);

    const onResize = () => {
      renderer.setSize(width(), height());
      camera.aspect = width() / height();
      camera.updateProjectionMatrix();
    };
    window.addEventListener("resize", onResize);

    // ---------- loop ----------
    let raf = 0;
    let last = performance.now();
    let moonValue = 65;
    let level = 1;
    let wave = 1;
    let waveTarget = monstersForWave(level, wave);
    let waveSpawned = 0;
    let waveDefeated = 0;
    let spawnT = 1.2;
    let noticeT = 2.6;
    let ended = false;
    const tmp = new THREE.Vector3();

    function beginWave() {
      waveTarget = monstersForWave(level, wave);
      waveSpawned = 0;
      waveDefeated = 0;
      spawnT = 1.2;
    }

    function loop(now: number) {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const paused = document.pointerLockElement !== renderer.domElement;

      if (paused) {
        renderer.render(scene, camera);
        raf = requestAnimationFrame(loop);
        return;
      }
      if (noticeT > 0) {
        noticeT -= dt;
        if (noticeT <= 0) setLevelNotice(n => ({ ...n, visible: false }));
      }

      // movement
      const forward = new THREE.Vector3(-Math.sin(player.yaw), 0, -Math.cos(player.yaw));
      const right   = new THREE.Vector3(Math.cos(player.yaw), 0, -Math.sin(player.yaw));
      const move = new THREE.Vector3();
      if (keys.has("w") || keys.has("arrowup")) move.add(forward);
      if (keys.has("s") || keys.has("arrowdown")) move.sub(forward);
      if (keys.has("d") || keys.has("arrowright")) move.add(right);
      if (keys.has("a") || keys.has("arrowleft")) move.sub(right);
      if (move.lengthSq() > 0) move.normalize().multiplyScalar(r.stats.speed * dt);
      player.pos.add(new THREE.Vector3(move.x, 0, move.z));
      // clamp
      player.pos.x = Math.max(-45, Math.min(45, player.pos.x));
      player.pos.z = Math.max(-45, Math.min(45, player.pos.z));
      // head bob
      const bob = move.lengthSq() > 0 ? Math.sin(now * 0.012) * 0.04 : 0;
      camera.position.set(player.pos.x, 1.7 + bob, player.pos.z);
      const lookDir = new THREE.Vector3(Math.cos(player.pitch) * -Math.sin(player.yaw), Math.sin(player.pitch), Math.cos(player.pitch) * -Math.cos(player.yaw));
      camera.lookAt(camera.position.clone().add(lookDir));
      if (role === "attacker") {
        const swing = Math.sin(scytheSwing * Math.PI);
        firstPersonScythe.position.set(0.62 - swing * 0.32, -0.58 + swing * 0.08, -1.05);
        firstPersonScythe.rotation.set(-0.34 + swing * 0.45, -0.34 - swing * 0.18, -0.1 - swing * 1.1);
        scytheSwing = Math.max(0, scytheSwing - dt * 4.6);
      }

      if (player.cool > 0) player.cool -= dt * 60;

      // healer regen
      if (role === "healer" && player.hp < r.stats.hp) player.hp = Math.min(r.stats.hp, player.hp + 2.4 * dt);

      defenderBubble.position.copy(player.pos);
      healerVision.position.set(player.pos.x, 0.12, player.pos.z);

      // moon visuals pulse
      moon.material.color.setRGB(0.78 + (moonValue / 100) * 0.22, 0.85 + (moonValue / 100) * 0.15, 1.0);
      (halo.material as THREE.SpriteMaterial).opacity = 0.4 + (moonValue / 100) * 0.6;
      moonGroup.rotation.y += dt * 0.02;
      localDreamCluster.position.lerp(tmp.set(player.pos.x, 0, player.pos.z), Math.min(1, dt * 1.8));
      localDreamCluster.rotation.y += dt * 0.025;

      // lamp flicker tied to moon health
      for (const l of lamps) {
        const t = 0.7 + (moonValue / 100) * 0.6;
        l.light.intensity = l.base * t * (0.9 + Math.sin(now * 0.004 + l.mesh.id) * 0.08);
      }

      // floating dream objects drift just enough to feel unstable.
      for (const o of dreamObjects) {
        o.phase += dt;
        o.group.position.y = o.baseY + Math.sin(o.phase * 0.75) * 0.45;
        o.group.rotation.x += o.spin.x * dt;
        o.group.rotation.y += o.spin.y * dt;
        o.group.rotation.z += o.spin.z * dt;
      }

      // dust drift
      const dp = (dust.geometry.attributes.position as THREE.BufferAttribute).array as Float32Array;
      for (let i = 0; i < dustCount; i++) {
        dp[i*3+1] += dt * 0.2 * (0.5 + Math.sin(i + now * 0.001));
        if (dp[i*3+1] > 10) dp[i*3+1] = 0.5;
      }
      (dust.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;

      // spawn finite waves for three escalating levels
      if (!ended && waveSpawned < waveTarget) {
        spawnT -= dt;
        if (spawnT <= 0) {
          spawnNightmare(level, wave, waveSpawned);
          waveSpawned++;
          spawnT = Math.max(0.75, 1.85 - level * 0.22 - wave * 0.08);
        }
      }

      // nightmares
      for (const n of nightmares) {
        const tx = player.pos.x;
        const tz = player.pos.z;
        const dpx = player.pos.x - n.group.position.x;
        const dpz = player.pos.z - n.group.position.z;
        const dp2 = dpx*dpx + dpz*dpz;
        tmp.set(tx - n.group.position.x, 0, tz - n.group.position.z);
        if (tmp.lengthSq() > 0.01) tmp.normalize().multiplyScalar(n.speed * dt);
        n.group.position.x += tmp.x;
        n.group.position.z += tmp.z;
        n.group.rotation.y = Math.atan2(tmp.x, tmp.z);
        // float bob
        n.group.position.y = 0.2 + Math.abs(Math.sin(now * 0.003 + n.group.position.x)) * 0.28;
        n.group.scale.y = 1 + Math.sin(now * 0.004 + n.group.position.z) * 0.06;
        // damage player
        if (Math.sqrt(dp2) < 1.4) {
          const levelDamage = 1 + (level - 1) * 0.12;
          if (player.shield > 0) {
            player.shield = Math.max(0, player.shield - (n.kind === "leech" ? 38 : 18) * levelDamage * dt);
          } else {
            player.hp -= (n.kind === "leech" ? 10.4 : 4.2) * levelDamage * dt;
          }
          moonValue -= (n.kind === "eclipse" ? 0.95 : 0.38) * levelDamage * dt;
        }
        if (n.kind === "eclipse") {
          moonValue -= (0.18 + (level - 1) * 0.055) * dt;
        }
        if (role === "healer") {
          const seenDist = player.pos.distanceTo(n.group.position);
          n.light.intensity = 1.5 + Math.max(0, 1 - seenDist / 48) * 1.35;
        } else {
          n.light.intensity = n.kind === "eclipse" ? 0.8 : n.kind === "leech" ? 0.62 : 0.45;
        }
      }

      // orbs
      for (const o of orbs) {
        o.mesh.position.addScaledVector(o.vel, dt);
        o.mesh.rotation.x += dt * 4.2;
        o.mesh.rotation.z += dt * 5.6;
        o.life -= dt;
        for (const n of nightmares) {
          if (o.mesh.position.distanceToSquared(n.group.position.clone().setY(o.mesh.position.y)) < 0.9) {
            const base = r.stats.dmg;
            if (role === "healer") {
              n.hp -= base;
              for (const other of nightmares) {
                if (other !== n && other.group.position.distanceTo(n.group.position) < 2.2) {
                  other.hp -= base * 0.72;
                }
              }
            } else {
              n.hp -= base;
            }
            burst(o.mesh.position.clone(), role === "leader" ? 0xffe66f : role === "healer" ? 0x92e0ff : 0xa9c8ff, role === "leader" ? 20 : 14);
            o.life = 0;
            break;
          }
        }
      }
      for (let i = orbs.length - 1; i >= 0; i--) {
        if (orbs[i].life <= 0) {
          scene.remove(orbs[i].mesh);
          orbs.splice(i, 1);
        }
      }

      if (role === "defender") {
        pickupT -= dt;
      }
      if (role === "defender" && pickupT <= 0) {
        if (pickups.length < 5) spawnPickupOrb();
        pickupT = 5.5 + Math.random() * 4.5;
      }
      for (let i = pickups.length - 1; i >= 0; i--) {
        const orb = pickups[i];
        orb.mesh.rotation.y += dt * 1.4;
        orb.light.intensity = 0.8 + Math.sin(now * 3 + i) * 0.25;
        orb.life -= dt;
        if (role === "defender" && orb.mesh.position.distanceTo(player.pos) < 2.2) {
          player.shield = Math.min(player.shieldMax, player.shield + 28);
          burst(orb.mesh.position.clone(), 0x8ef1ff, 10);
          scene.remove(orb.mesh);
          pickups.splice(i, 1);
          continue;
        }
        if (orb.life <= 0) {
          scene.remove(orb.mesh);
          pickups.splice(i, 1);
        }
      }

      // cleanse
      for (let i = nightmares.length - 1; i >= 0; i--) {
        if (nightmares[i].hp <= 0) {
          burst(nightmares[i].group.position.clone().setY(1.5), 0xcfe4ff, 24);
          scene.remove(nightmares[i].group);
          nightmares.splice(i, 1);
          waveDefeated++;
          moonValue += 7;
        }
      }

      if (!ended && waveSpawned >= waveTarget && waveDefeated >= waveTarget && nightmares.length === 0) {
        if (wave < LEVEL_WAVES[level - 1]) {
          wave++;
          moonValue = Math.min(100, moonValue + 8);
          beginWave();
        } else if (level < LEVEL_WAVES.length) {
          level++;
          wave = 1;
          moonValue = Math.min(100, moonValue + 12);
          player.hp = Math.min(r.stats.hp, player.hp + r.stats.hp * 0.28);
          setLevelNotice({ level, visible: true });
          noticeT = 2.8;
          beginWave();
        } else {
          ended = true;
          document.exitPointerLock?.();
          onWinRef.current();
        }
      }

      // role passives
      if (role === "leader") {
        moonValue += 0.12 * dt;
      }
      if (role === "defender") moonValue += 0.16 * dt;

      // particles
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.mesh.position.addScaledVector(p.vel, dt);
        p.vel.multiplyScalar(0.94);
        p.life -= 1;
        (p.mesh.material as THREE.MeshBasicMaterial).opacity = p.life / p.max;
        if (p.life <= 0) { scene.remove(p.mesh); particles.splice(i, 1); }
      }

      moonValue = Math.max(0, Math.min(100, moonValue));
      player.hp = Math.max(0, Math.min(r.stats.hp, player.hp));

      setHud(h => ({ ...h, hp: Math.round((player.hp / r.stats.hp) * 100), moon: Math.round(moonValue), level, wave, wavesInLevel: LEVEL_WAVES[level - 1], shield: role === "defender" ? Math.round((player.shield / player.shieldMax) * 100) : 0 }));

      if (!ended) {
        if (player.hp <= 0 || moonValue <= 0) { ended = true; document.exitPointerLock?.(); onLoseRef.current(); }
      }

      renderer.render(scene, camera);
      raf = requestAnimationFrame(loop);
    }
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("keydown", onKD);
      window.removeEventListener("keyup", onKU);
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("pointerlockchange", onLockChange);
      window.removeEventListener("resize", onResize);
      renderer.domElement.removeEventListener("click", onClick);
      try { document.exitPointerLock?.(); } catch { /* noop */ }
      renderer.dispose();
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
    };
  }, [role]);

  const changeRole = () => {
    try { document.exitPointerLock?.(); } catch { /* noop */ }
    onChangeRole();
  };

  return (
    <section className="relative min-h-screen overflow-hidden bg-[#050b1f]">
      <div className="absolute inset-0 cursor-crosshair" ref={mountRef} />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_15%,rgba(190,215,255,0.12),transparent_26%),linear-gradient(180deg,transparent_65%,rgba(0,0,0,0.34))]" />
      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 p-4 md:p-6">
        <div className="mx-auto w-full max-w-6xl rounded-lg border border-primary/20 bg-[#061024cc] px-4 py-3 shadow-[0_18px_60px_rgba(0,0,0,0.3)] backdrop-blur">
          <div className="mb-3 flex flex-col gap-2 text-center md:flex-row md:items-center md:justify-between">
          <div className="font-display tracking-[0.3em] text-sm text-primary">{ROLES[role].name.toUpperCase()}</div>
          <div className="text-xs uppercase tracking-[0.3em] text-slate-200/70">WASD · Mouse to look · Click / Space to use your role ability</div>
          <div className="flex flex-col items-center gap-2 md:flex-row">
            <div className="font-display tracking-[0.3em] text-sm text-primary">Level {hud.level} · Wave {hud.wave}/{hud.wavesInLevel}</div>
            <button onClick={changeRole} className="pointer-events-auto rounded-full border border-primary/40 bg-primary/15 px-4 py-1.5 text-[10px] uppercase tracking-[0.25em] text-primary transition hover:bg-primary/25">
              Change Character
            </button>
          </div>
        </div>
          <div className={`grid gap-3 ${role === "defender" ? "grid-cols-3" : "grid-cols-2"}`}>
          <Meter label="Your Light" value={hud.hp} tone="hp" />
          <Meter label="The Moon" value={hud.moon} tone="moon" />
          {role === "defender" ? <Meter label="Shield" value={hud.shield} tone="hp" /> : null}
        </div>
        </div>
      </div>
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="h-3 w-3 rounded-full border border-primary/80" />
          </div>
          {levelNotice.visible && (
            <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center px-6">
              <div className="rounded-lg border border-primary/35 bg-[#061024e6] px-8 py-6 text-center shadow-[0_0_70px_rgba(150,190,255,0.22)] backdrop-blur-md">
                <div className="text-xs uppercase tracking-[0.45em] text-slate-200/70">New Level</div>
                <div className="mt-2 font-display text-5xl text-primary text-glow">Level {levelNotice.level}</div>
                <div className="mt-3 text-xs uppercase tracking-[0.3em] text-slate-200/75">{LEVEL_WAVES[levelNotice.level - 1]} waves incoming</div>
              </div>
            </div>
          )}
          {!hud.locked && (
            <div ref={overlayRef} className="pointer-events-none absolute inset-0 flex items-center justify-center bg-[#081123d9] backdrop-blur-sm">
              <div className="text-center px-6">
                <div className="font-display text-2xl text-white text-glow">CLICK TO ENTER OR RESUME THE DREAM</div>
                <p className="mt-2 text-sm text-slate-200 italic">The game is paused while your cursor is free.</p>
              </div>
            </div>
          )}
    </section>
  );
}

function Meter({ label, value, tone }: { label: string; value: number; tone: "hp" | "moon" }) {
  const color = tone === "hp"
    ? "linear-gradient(90deg, oklch(0.55 0.18 255), oklch(0.85 0.13 235))"
    : "linear-gradient(90deg, oklch(0.45 0.20 260), oklch(0.95 0.08 235))";
  return (
    <div>
      <div className="flex justify-between text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-1">
        <span>{label}</span><span>{value}%</span>
      </div>
      <div className="h-2 rounded-full bg-card/60 border border-border overflow-hidden">
        <div className="h-full transition-[width] duration-150" style={{ width: `${value}%`, background: color }} />
      </div>
    </div>
  );
}

/* ---------------- end ---------------- */
function EndScreen({ win, role, onRetry, onMenu }: { win: boolean; role: RoleKey; onRetry: () => void; onMenu: () => void }) {
  return (
    <section className="relative flex min-h-screen items-center justify-center px-6 text-center">
      <div>
        <div className={`mx-auto mb-8 h-40 w-40 rounded-full moon-glow ${win ? "animate-shimmer" : "opacity-40"}`}
          style={{ background: win
            ? "radial-gradient(circle at 35% 30%, #eaf3ff, #9cbef0 45%, #2d4e8a 80%)"
            : "radial-gradient(circle at 50% 50%, #2a0e3a, #050010 80%)" }} />
        <h2 className="font-display text-5xl text-glow text-primary">{win ? "The Dream Is Cleansed" : "Dawn Never Came"}</h2>
        <p className="mt-4 max-w-xl mx-auto italic text-muted-foreground text-lg">
          {win
            ? `As ${ROLES[role].name.toLowerCase()}, you cleansed the nightmare from this dream and restored a little light to the moon. The darkness has not vanished, but hope glows again.`
            : "Nightmares have corrupted too many dreams. The moon's glow dims, and the town must fight to reclaim its peace."}
        </p>
        <div className="mt-10 flex justify-center gap-3">
          <button onClick={onRetry} className="font-display rounded-full border border-primary/50 bg-primary/20 px-8 py-2.5 text-xs tracking-[0.3em] text-primary hover:bg-primary/30 transition">TRY AGAIN</button>
          <button onClick={onMenu} className="font-display rounded-full border border-border px-8 py-2.5 text-xs tracking-[0.3em] text-muted-foreground hover:text-foreground transition">MENU</button>
        </div>
      </div>
    </section>
  );
}
